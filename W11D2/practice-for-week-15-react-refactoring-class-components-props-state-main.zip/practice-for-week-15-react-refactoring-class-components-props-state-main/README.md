# Code for Class Component Videos

To access the code that is used in the Class Component videos, click the
`Download Project` button at the bottom of this page and load the repo into
[CodeSandbox].

[CodeSandbox]: https://www.codesandbox.io